public enum FoodType {
    RECIPE,
    PROTEIN,
    CARB,
    FAT,
    FIBER
}
